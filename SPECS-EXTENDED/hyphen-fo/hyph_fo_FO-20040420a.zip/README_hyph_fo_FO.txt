Hyphenation dictionary
----------------------

Language: Faroese (Faroe Islands) (fo FO).
Origin:   Generated from a collection of hyphenated words provided by the
          newspaper Dimmal�tting.
License:  GNU GPL
Author:   jacob@flug.fo (Jacob Sparre Andersen)

HYPH fo FO hyph_fo_FO

