Installatschoon vun hunspell-nds för OpenOffice:
(Wohrschau: dat geiht eerst mit OpenOffice 2.4 un later. 
Bet 2.3 kannst Du de Spraak Plattdüütsch nich utwählen!!)

De twee Lexikondateien sünd 
nds.aff
nds.dic

Disse Dateien muttst Du in den Dateiboom vun OpenOffice koperen. 
Woneem dat is, hangt en beten vun Dien Installatschoon af.
* ünner Linux is dat tomehrst in 
  /opt/openoffice.org2.4/share/dict/ooo
* ünner Windows is dat tomehrst in 
  C:\Programme\OpenOffice.org 2.4\share\dict\ooo

Dor steiht ok al en Barg annere Wöörnböker so as 
de_DE.aff etc.

Denn mutt noch de Datei 
/opt/openoffice.org2.4/share/dict/ooo/dictionary.lst
(oder ünner Windows:C:\Programme\OpenOffice.org 2.4\share\dict\ooo\dictionary.lst)
anpasst warrn:
disse Reeg tofögen:
-------
DICT nds DE nds
--------

Un denn Open Office tomaken un nieg hoochfohrn.

Denn kannst Du en Text in OpenOffice as Plattdüütsch markeren:
Menü Extras/Sprache/Für den gesamten Text/Mehr...
Denn geiht en Dialog op un dor muttst Du "Niederdeutsch" rutsöken.





