S�ownik synonim�w - wersja do programu OpenOffice.org
Copyright (C) 2004-2007 Marcin Mi�kowski <milek_pl@users.sourceforge.net>
Wersja wygenerowana automatycznie dnia YYYY-MM-DD HH:MM
Strona g��wna: http://synonimy.ux.pl/

Wymagania: ==========================================================

 OpenOffice.org 2.0beta lub nowszy - nie dzia�a ze starszymi wersjami

Instalacja: =============================================================

 1. Skopiowa� pliki th_pl_PL_v2.dat.dat i th_pl_PL_v2.idx do nast�puj�cego
    katalogu:
    OpenOffice.org/share/dict/ooo/
    Po�o�enie tego katalogu zale�y od instalacji.
    W systemie Linux jest to cz�sto /usr/local lub /opt, 
    w systemie Windows najcz�ciej C:\Program Files.

 2. Do pliku OpenOffice.org/share/dict/ooo/dictionary.lst
    dopisa� nast�puj�cy wiersz:
    THES pl PL th_pl_PL_v2

 3. Uruchomi� OOo od nowa (tak�e modu� szybkiego uruchamiania, je�li
    jest u�ywany).

 4. Zaznaczy� wyraz w tek�cie lub ustawi� na nim kursor i wybra� polecenie
    Narz�dzia->Tezaurus. Je�li nie pojawi� si� synonimy, mo�na wypr�bowa�
    wyraz "test". Znajdowane s� poza tym tylko formy podstawowe 
    (nie odmienione).

    Znalezione b��dy lub zauwa�one luki mo�na poprawi� na stronie
    http://synonimy.ux.pl/.

This product is made available subject to the terms of GNU Lesser 
General Public License Version 2.1.