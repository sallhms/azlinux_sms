_______________________________________________________________________________

	DICCIONARI DE CORRECCIÓ ORTOGRÀFICA HUNSPELL
	versió 3.0.8

	Copyright (C) 2013-2023 Jaume Ortolà <jaumeortola@gmail.com>
  
	Llicència (a la vostra elecció):
		LGPL v. 2.1 o superior --  http://www.gnu.org/licenses/lgpl-2.1.html
		GPL v.2.0 o superior --  http://www.gnu.org/licenses/gpl-2.0.html

	Més informació:
  		https://www.softcatala.org/projectes/corrector-ortografic/
_______________________________________________________________________________
