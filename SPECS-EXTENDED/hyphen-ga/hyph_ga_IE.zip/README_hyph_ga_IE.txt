Hyphenation dictionary
----------------------

Language: Irish (ga IE).  
Origin:   Based on the TeX hyphenation tables 
License:  GNU GPL
Author:   Kevin P. Scannell <scannell@slu.edu>

HYPH ga IE hyph_ga_IE


For detailed remarks on the method of construction,
see my web page:
   http://borel.slu.edu/fleiscin/index.html

The original TeX file `gahyph.tex' from which these patterns are taken
is available from CTAN: 

http://www.ctan.org/tex-archive/language/hyphenation/

or directly from the author <scannell@slu.edu>.

- Kevin Scannell, 2004-01-23
