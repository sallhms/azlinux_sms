Slovak thesaurus database
=========================

Copyright (c) 2004-2010 Tibor Bako, yorik (zavinac) szm.sk,
Zdenko Podobný, zdposter (zavinac) gmail.com

Permission is hereby granted, free of charge, to any person obtaining
a copy of this data (the "Data"), to deal in the Data without
restriction, including without limitation the rights to use, copy,
modify, merge, publish, distribute, sublicense, and/or sell copies of
the Data, and to permit persons to whom the Data is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Data.

THE DATA ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE DATA OR THE USE OR OTHER DEALINGS IN THE DATA.

*****************************************************************


Slovenské dáta pre synonymický slovník (Thesaurus) v OpenOffice.org 2.x
=======================================================================


Inštalácia
==========

Inštalácia pozostáva z týchto krokov:

1. Nakopírovať súbory th_sk_SK.dat a th_sk_SK.idx do priečinku
   <OOo>/share/dict/ooo

Poznámka: Vyie uvedený priečinok nemusí by ten správny ;-). Správny 
    priečinok nájdete v OpenOffice.org v menu v Nástrojoch -> Vožby -> 
    OpenOffice.org -> Cesty -> Pomôcky pre písanie.

2. Pridať riadok
   THES sk SK th_sk_SK
   do súboru <Ooo>/share/dict/ooo/dictionary.lst

3. Spustiť OpenOffice.org (ak je spustený, tak je potrebné ho reštartovať)
   povoliť použitie Synonymického slovníku zaškrtnutím voľby "OpenOffice.org
   Thesaurus" v ponuke Nástroje -> Voľby -> Nastavenie jazyka -> 
   Pomôcky pre písanie.


Zdenko Podobný <zdposter (zavinac) gmail (bodka) com>
http://lingucomponent.openoffice.org/download_dictionary.html
