Hyphenation dictionary
----------------------

Language: Icelandic (Iceland) (is IS).
Origin:   Based on the TeX hyphenation tables
License:  LGPL/SISSL license, 2003
Author:   akig@hi.is (�ki G. Karlsson)

HYPH is IS hyph_is_IS


 These patterns were converted from TeX hyphenation patterns by J�rgen Pind
 (1987).
 
 -- 
 �ki G. Karlsson
 2003
 
