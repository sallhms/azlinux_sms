0. Malpera MySpell a kurd�:
      http://www.linux-ku.com/myspell 
   Ji bo z�detir agah�: 
      http://ku.wikipedia.org/wiki/MySpell
      http://ku.wikipedia.org/wiki/DicOOo

1. Version 0.20

2. Sazkirin / Installation

2.1. SAZKIRIN JI BO OpenOffice.org 2.0 (beta) bi DicOOo 1.4.1

  Fonksyona z�dekirina ferhengan heye (File>Wizards>Install new dictionaries...). Li v� der� bernameya DicOOo t� dan dest p� kirin. Bi DicOOo 1.4.1 � mezintir mirov dikare b� zehmet paket�n kurd� y�n MySpell saz bike.

2.2. SAZKIRIN JI BO OpenOffice 1.1
  Ji ber ku ziman� kurd� h�n di nav ziman�n ferm� y�n OpenOffice.org 1.1 de tune, mirov mecb�ren bi xwe saz bike. Eger s�stema te Microsoft Windows be, klasoreke wek�

>>  "c:\program files\OpenOffice.org1.1.x\share\dict\ooo"  <<

bib�ne. T� de hem� ferheng hene. Pak�ta "ku_TR.zip" veke � her s� dosyayan derbas� v� klasor� bike.
(ku_TR.dic, ku_TR.aff � README_ku_TR.txt)

  Di v� klasor� de dosyayeke bi nav� "DICTIONARY.LST" heye. T� de l�steya ferheng�n hey� heye. V� dosyay� veke � r�za

>>  DICT af ZA ku_TR  <<

z�de bike. Niha OpenOffice.org ji bo ziman� "Afrikaans" ferhenga kurd� bi kar t�ne. Komp�tera xwe bigre � d�sa veke. Xelas. Ji bo belgey�n bi kurd� ziman� "Afrikaans" bi kar b�ne.

3. D�ROKA VERSIYONAN

0.20 30.01.2005 Gelek peyvan z�de kir, affix z�dekir. Spas ji bo al�kariya Omer Dilsoz.
0.13 22.01.2005 ~10.000 peyv
0.12 20.01.2005 Serastkirin�n bi��k
0.10 08.09.2004 ~9.000 peyv - versiyona ewil, gelek kemas�, ~9.000

4. Copyright
Myspell dictionary for Kurdish
Copyright 2004-2007 Erdal Ronahi <erdal.ronahi@gmx.net>
With contributions from Kevin P. Scannell <scannell@slu.edu>
and R�zan Tovj�n <retovjin@hotmail.com>

  The original word list used for this package was augmented
using Scannell's web crawling software "An Cr�bad�n" and 
then hand-checked by Ronahi and Tovj�n.

5. License

Originally GPL, relicensed on 04-07-2007 to GPLv3, LGPLv3, MPL 1.1
