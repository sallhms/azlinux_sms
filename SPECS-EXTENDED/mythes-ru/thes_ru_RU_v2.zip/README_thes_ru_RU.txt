Russian Thesaurus Dictionary for OpenOffice.org 2
-------------------------------------------------

Language: Russian (ru RU)
License:  GNU LGPL
Author:   Mikhail Korolyov <mkorolyov@yandex.ru>
Origin:   Абрамовъ, Н. Словарь русскихъ синонимовъ и сходныхъ по смыслу выраженiй. Изд. 3-е, доп., Пг., 1911
Packager: Rail Aliev <rail@i-rs.ru>
