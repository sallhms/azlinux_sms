The Slovenian patterns for hyphenation were created by:
Matjaz Vrecko, MG-SOFT Corp. <matjaz.vrecko@mg-soft.si>
and is covered by the GNU/LGPL and GNU/GPL License and  
supports Slovenian language (sl_SI)

For use in OpenOffice.org adapted by:
Robert Ludvik <r@aufbix.org>

HYPH sl SI hyph_sl_SI


=======================================================================================
http://external.openoffice.org/ form data:

Product Name: Slovenian patterns for hyphenation
Product Version: 1.0
Vendor or Owner Name: Matjaz Vrecko 
Vendor or Owner Contact: matjaz.vrecko@mg-soft.si
OpenOffice.org Contact: bobe@openoffice.org
Date of First Use / date of License: 1990/October 2006
URL for Product Information:
http://vlado.fmf.uni-lj.si/texceh/kako/delilni/delilni.htm
URL for License: http://www.gnu.org/copyleft/lgpl.html
Purpose: Patterns for Slovenian hyphenation
Type of Encryption: none
Binary or Source Code: Source
=======================================================================================
